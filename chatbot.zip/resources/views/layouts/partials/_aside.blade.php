<?php

?>

<aside class="aside">
    <!-- Aside Header -->
    <div class="aside-header">
        <!-- Aside Toggle Menu Button -->
        <button class="toggle-menu-button aside-toggle border-0 bg-transparent p-0 bgwhite">
            <span class="material-icons">menu</span>
        </button>
        <!-- End Aside Toggle Menu Button -->
    </div>
    <!-- End Aside Header -->

    <!-- Aside Body -->
    <div class="aside-body" data-trigger="scrollbar">


        <!-- Nav -->
        <ul class="nav">
            <li class="nav-category bgwhite">main</li>
            <li>
                <a href="{{route('admin.dashboard')}}" class="{{request()->is('admin/dashboard')?'active-menu':''}}">
                    <span class="material-icons" title="dashboard">dashboard</span>
                    <span class="link-title">dashboard</span>
                </a>
            </li>

            <li>
                <a href="{{route('admin.message')}}" class="{{request()->is('admin/message')?'active-menu':''}}">
                    <span class="material-icons" title="chat">chat</span>
                    <span class="link-title">Message</span>
                </a>
            </li>
          
            <li>
                <a href="{{route('admin.doctors')}}" class="{{request()->is('admin/doctors')?'active-menu':''}}">
                    <span class="material-icons" title="watch">watch</span>
                    <span class="link-title">Doctors</span>
                </a>
            </li>
     

{{-- 
                <li>
                    <a href="{{route('admin.employee.index')}}"
                       class="{{request()->is('admin/employee/list')?'active-menu':''}}">
                        <span class="material-icons" title="{{translate('employee_list')}}">list</span>
                        <span class="link-title">{{translate('employee list')}}</span>
                    </a>
                </li> --}}


            </ul>

        

        </ul>
        <!-- End Nav -->
    </div>
    <!-- End Aside Body -->
</aside>
