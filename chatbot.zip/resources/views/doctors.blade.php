@extends('layouts.master')

@section('title','Doctors')

@push('css_or_js')
    <link rel="stylesheet" href="{{asset('public/assets')}}/plugins/select2/select2.min.css"/>
    <link rel="stylesheet" href="{{asset('public/assets')}}/plugins/dataTables/jquery.dataTables.min.css"/>
    <link rel="stylesheet" href="{{asset('public/assets')}}/plugins/dataTables/select.dataTables.min.css"/>
@endpush

@section('content')
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-wrap mb-3">
                        <h2 class="page-title">Doctors</h2>
                    </div>

                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="all-tab-pane">
                            <div class="card">
                                <div class="card-body">
                                    <div class="data-table-top d-flex flex-wrap gap-10 justify-content-between">
                                        <form action="{{url()->current()}}" class="search-form search-form_style-two"
                                              method="POST">
                                            @csrf
                                            <div class="input-group search-form__input_group">
                                            <span class="search-form__icon">
                                                <span class="material-icons">search</span>
                                            </span>
                                                <input type="search" class="theme-input-style search-form__input"
                                                       value="{{$search}}" name="search"
                                                       placeholder="search here">
                                            </div>
                                            <button type="submit" class="btn btn--primary">Search</button>
                                        </form>
                                        
                                        <a href="{{route('admin.add-doctors')}}" class="btn btn--primary">
                                                                                  Add new

                                        </a>

                                   
                                    </div>

                                    <div class="table-responsive">
                                        <table id="example" class="table align-middle">
                                            <thead class="align-middle">
                                            <tr>
                                                <th>SL</th>
                                                <th>Name</th>
                                                 <th>Designation</th>
                                                                                                  <th>Specialist</th>

                                                 <th>Address</th>
                                                <th>Phone</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($products as $key=>$category)
                                                <tr>
                                                    <td>{{1+$key}}</td>
                                                    <td>{{$category['doctor_name']}}</td>
                                                                                                      <td>{{$category['designation']}}</td>
                                                                                                                                                                                                            <td>{{$category['diseases']}}</td>

                                                                                                      <td>{{$category['address']}}</td>
                                                                                                      <td>{{$category['phone']}}</td>
                                                    <td>
                                                        <div class="table-actions">
                                             
                                                            <button type="button"
                                                                    @if(env('APP_ENV')!='demo')
                                                                    onclick="form_alert('delete-{{$category['id']}}','want to delete this category?')"
                                                                    @endif
                                                                    class="table-actions_delete bg-transparent border-0 p-0 demo_check">
                                                                <span class="material-icons">delete</span>
                                                            </button>
                                                            <form action="{{route('admin.doctors-destroy',$category['id'])}}"
                                                                  method="post" id="delete-{{$category['id']}}" class="hidden">
                                                                @csrf
                                                                @method('DELETE')
                                                            </form>
                                                        </div>
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 
@endsection

@push('script')
    <script src="{{asset('public/assets')}}/plugins/select2/select2.min.js"></script>
    <script src="{{asset('public/assets')}}/plugins/dataTables/jquery.dataTables.min.js"></script>
    <script src="{{asset('public/assets')}}/plugins/dataTables/dataTables.select.min.js"></script>

@endpush
