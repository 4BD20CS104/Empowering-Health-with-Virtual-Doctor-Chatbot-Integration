<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductsController;
use App\Http\Controllers\LoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get('/', function () {
    return redirect('auth/login');
});
Route::group(['prefix' => 'auth', 'as' => 'auth.'], function () {
    Route::get('login',  [LoginController::class, 'login'])->name('login');
    Route::post('login', [LoginController::class, 'admin_login']);
    Route::get('logout', [LoginController::class,'logout'])->name('logout');
});

Route::group(['prefix' => 'admin', 'as' => 'admin.'], function () {
    Route::get('dashboard', 'AdminController@dashboard')->name('dashboard');
    Route::any('message', 'AdminController@message')->name('message');

    Route::post('message-store', 'AdminController@messageStore')->name('message-store');
    Route::post('message-update/{id}', 'AdminController@messageUpdate')->name('message-update');
    Route::delete('message-destroy/{id}', 'AdminController@messageDestroy')->name('message-destroy');
    
    Route::any('doctors', 'ProductsController@doctors')->name('doctors');
    Route::get('add-doctors', 'ProductsController@upload')->name('add-doctors');
    Route::post('doctors-store', 'ProductsController@store')->name('doctors-store');
    Route::post('doctors-update/{id}', 'ProductsController@update')->name('doctors-update');
    Route::delete('doctors-destroy/{id}', 'ProductsController@destroy')->name('doctors-destroy');


});