<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

    Route::group(['prefix' => 'auth', 'as' => 'auth.'], function () {
        Route::post('registration', 'LoginController@customer_register')->name('registration');
        Route::post('store-registration', 'LoginController@store_register')->name('store-registration');
        Route::post('login', 'LoginController@customer_login')->name('login');
        Route::post('logout', 'LoginController@customer_logout')->middleware('auth:api');
                Route::post('add-boys', 'LoginController@add_boys')->name('add-boys');

    });
    Route::get('response', 'ApiController@response')->name('response');
    Route::any('saveData', 'ApiController@saveData')->name('saveData');
    Route::any('getData', 'ApiController@getData')->name('getData');
        Route::any('login', 'ApiController@customer_login')->name('login');
        Route::any('register', 'ApiController@customer_register')->name('register');
        Route::any('book', 'ApiController@book')->name('book');

