<?php $__env->startSection('title','Sub Category'); ?>

<?php $__env->startPush('css_or_js'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets')); ?>/plugins/select2/select2.min.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets')); ?>/plugins/dataTables/jquery.dataTables.min.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets')); ?>/plugins/dataTables/select.dataTables.min.css"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-wrap mb-3">
                        <h2 class="page-title">Sub category</h2>
                    </div>

                    <!-- Category Setup -->
                    <div class="card category-setup mb-30">
                        <div class="card-body p-30">
                            <form action="<?php echo e(route('admin.category-store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                            <div class="col-lg-8 mb-5 mb-lg-0">
                                        <select class="select-identity theme-input-style mb-30" name="parent_id"
                                                required>
                                            <option selected disabled>Categories</option>
                                            <?php $__currentLoopData = $mcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mcategor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($mcategor->id); ?>"><?php echo e($mcategor->name); ?></option>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    <div class="col-lg-8 mb-5 mb-lg-0">
                                        <div class="d-flex flex-column">
                                            <div class="form-floating mb-30">
                                                <input type="text" name="category" class="form-control"
                                                       value="<?php echo e(old('category')); ?>"
                                                       placeholder="sub category" required>
                                                <label>Sub category</label>
                                            </div>

                        
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="d-flex justify-content-end gap-20 mt-30">
                                            <button class="btn btn--secondary"
                                                    type="reset">Reset</button>
                                            <button class="btn btn--primary" type="submit">Submit
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- End Category Setup -->


                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="all-tab-pane">
                            <div class="card">
                                <div class="card-body">
                                    <div class="data-table-top d-flex flex-wrap gap-10 justify-content-between">
                                        <form action="<?php echo e(url()->current()); ?>" class="search-form search-form_style-two"
                                              method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="input-group search-form__input_group">
                                            <span class="search-form__icon">
                                                <span class="material-icons">search</span>
                                            </span>
                                                <input type="search" class="theme-input-style search-form__input"
                                                       value="<?php echo e($search); ?>" name="search"
                                                       placeholder="search here">
                                            </div>
                                            <button type="submit" class="btn btn--primary">Search</button>
                                        </form>

                                   
                                    </div>

                                    <div class="table-responsive">
                                        <table id="example" class="table align-middle">
                                            <thead class="align-middle">
                                            <tr>
                                                <th>SL</th>
                                                <th>Category</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(1+$key); ?></td>
                                                    <td><?php echo e($category['name']); ?></td>
                                                    <td>
                                                        <div class="table-actions">
                                                    <button type="button"   class="table-actions_delete bg-transparent border-0 p-0 demo_check" data-bs-toggle="modal"
                                                    data-bs-target="#updateModal--<?php echo e($category['id']); ?>"
                                                    data-toggle="tooltip" title="">
                                                                <span class="material-icons">edit</span>
                                            </button>
                                            
                                                            <button type="button"
                                                                    <?php if(env('APP_ENV')!='demo'): ?>
                                                                    onclick="form_alert('delete-<?php echo e($category['id']); ?>','want to delete this category?')"
                                                                    <?php endif; ?>
                                                                    class="table-actions_delete bg-transparent border-0 p-0 demo_check">
                                                                <span class="material-icons">delete</span>
                                                            </button>
                                                            <form action="<?php echo e(route('admin.category-destroy',$category['id'])); ?>"
                                                                  method="post" id="delete-<?php echo e($category['id']); ?>" class="hidden">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                            </form>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="d-flex justify-content-end">
                                        <?php echo $categories->links(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
       <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
       <div class="modal fade" id="updateModal--<?php echo e($category['id']); ?>" tabindex="-1"
     aria-labelledby="updateModalLabel"
     aria-hidden="true">
        <div class="modal-dialog modal-lg  modal-dialog-centered" style="--bs-modal-width: 430px">
               <div class="modal-content">
                   
                        <div class="modal-header px-4 pt-4 border-0 pb-1">
                <h3 class="text-capitalize">Edit</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
                         
              <div class="modal-body">
                <form action="<?php echo e(route('admin.category-update',['id' => $category['id']])); ?>" method="POST" id="edit-table-<?php echo e($key); ?>">
                   <?php echo csrf_field(); ?>
                   <div class="row">
                  <div class="col-md-6 col-lg-12">
                        <div class="mb-30">
                            <div class="form-floating">
                                <input type="text" class="form-control" name="name" id="name"
                                       placeholder="name" 
                                       value="<?php echo e($category['name']); ?>"
                                     required>
                                <label>Name</label>
                            </div>
                        </div>
                    </div>
                  </div>
                  </form>
             </div>
            
              <div class="modal-footer d-flex justify-content-end gap-3 border-0 pt-0 pb-4">
                <button type="button" class="btn btn--secondary" data-bs-dismiss="modal" aria-label="Close">Cancel</button>
                <button type="submit" class="btn btn--primary" form="edit-table-<?php echo e($key); ?>">update</button>
            </div>
            
             </div>
      </div>    

</div>    
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('public/assets')); ?>/plugins/select2/select2.min.js"></script>
    <script src="<?php echo e(asset('public/assets')); ?>/plugins/dataTables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('public/assets')); ?>/plugins/dataTables/dataTables.select.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/beauty/beauty/resources/views/subcategory.blade.php ENDPATH**/ ?>