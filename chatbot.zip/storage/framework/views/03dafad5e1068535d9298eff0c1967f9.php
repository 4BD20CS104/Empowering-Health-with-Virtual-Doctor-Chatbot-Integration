<?php

?>

<aside class="aside">
    <!-- Aside Header -->
    <div class="aside-header">
        <!-- Aside Toggle Menu Button -->
        <button class="toggle-menu-button aside-toggle border-0 bg-transparent p-0 bgwhite">
            <span class="material-icons">menu</span>
        </button>
        <!-- End Aside Toggle Menu Button -->
    </div>
    <!-- End Aside Header -->

    <!-- Aside Body -->
    <div class="aside-body" data-trigger="scrollbar">


        <!-- Nav -->
        <ul class="nav">
            <li class="nav-category bgwhite">main</li>
            <li>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->is('admin/dashboard')?'active-menu':''); ?>">
                    <span class="material-icons" title="dashboard">dashboard</span>
                    <span class="link-title">dashboard</span>
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('admin.category')); ?>" class="<?php echo e(request()->is('admin/category')?'active-menu':''); ?>">
                    <span class="material-icons" title="category">category</span>
                    <span class="link-title">category</span>
                </a>
            </li>
          
            <li>
                <a href="<?php echo e(route('admin.sub-category')); ?>" class="<?php echo e(request()->is('admin/dashboard')?'active-menu':''); ?>">
                    <span class="material-icons" title="category">category</span>
                    <span class="link-title">Sub category</span>
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('admin.products')); ?>" class="<?php echo e(request()->is('admin/dashboard')?'active-menu':''); ?>">
                    <span class="material-icons" title="watch">watch</span>
                    <span class="link-title">Products</span>
                </a>
            </li>
                 <li>
                <a href="<?php echo e(route('admin.users')); ?>" class="<?php echo e(request()->is('admin/users')?'active-menu':''); ?>">
                    <span class="material-icons" title="user">chat</span>
                    <span class="link-title">Users</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.shops')); ?>" class="<?php echo e(request()->is('admin/shops')?'active-menu':''); ?>">
                    <span class="material-icons" title="watch">shop</span>
                    <span class="link-title">Shops</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('admin.requsts_shops')); ?>" class="<?php echo e(request()->is('admin/requsts_shops')?'active-menu':''); ?>">
                    <span class="material-icons" title="watch">shop</span>
                    <span class="link-title">Shop Requsts</span>
                </a>
            </li>




            </ul>

        

        </ul>
        <!-- End Nav -->
    </div>
    <!-- End Aside Body -->
</aside>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/beauty/beauty/resources/views/layouts/partials/_aside.blade.php ENDPATH**/ ?>