<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Products;
use Illuminate\Http\RedirectResponse;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use MongoDB\Driver\Manager;
use App\Models\DeliveryBoy;
use Illuminate\Support\Facades\Hash;
class LoginController extends Controller
{
    public function login()
    {
       return view('login');
    }
 public function logout()
    {
        auth()?->logout();
        return redirect()->to('/auth/login');
    }
    public function admin_login(Request $request): RedirectResponse
    {
        $validator = Validator::make($request->all(), [
            'email_or_phone' => 'required',
            'password' => 'required',    
        ], [
              ]);

        $user = User::where('email',$request->email_or_phone)->first();
    
        if (isset($user) && Hash::check($request['password'], $user->password)) {
         
            //if (auth()->login($user)){
                    return redirect()->route('admin.dashboard');
          // }
            
            return back();
        }

        Toastr::error('Invalid Credentials');
        return back();
    }
    
    public function customer_login(Request $request){
        
        $user = User::where('email',$request->email)->first();
    //  && $request['pass'] == $user['password']
        if (isset($user)) {
            if($user['is_active']==1){
                return response()->json(  [
                'response_code' => '200',
                'user_id'=>$user->id,
                'user_type'=>$user->type,
                'message' => 'Successfully registered'
                    ], 200);
            }
             return response()->json(  [
                    'response_code' => '201',
                    'message' => 'Shop is Under approval'
                        ], 201);
        }
      return response()->json(  [
        'response_code' => '201',
        'message' => 'Invalid Credentials'
            ], 201);
    }
    
    
    public function customer_register(Request $request){
        
                $exist = User::where('email',$request->email)->first();
if($exist){
     return response()->json(  [
        'response_code' => '201',
        'message' => 'Account already exists'
            ], 201);
    
}
        $user = new User();
        $user->name = $request->name;
        $user->password = $request->pass;
        $user->email = $request->email;
        $user->type=0;
        $user->is_active=1;
        $user->save();
        
     return response()->json(  [
        'response_code' => '200',
        'message' => 'Successfully registered'
            ], 200);
    }
    
    public function store_register(Request $request){
        
                $exist = User::where('email',$request->email)->first();
if($exist){
     return response()->json(  [
        'response_code' => '201',
        'message' => 'Account already exists'
            ], 201);
    
}
        $user = new User();
        $user->name = $request->name;
        $user->store_name = $request->store_name;
        $user->address = $request->address;
        $user->phone = $request->phone;
        $user->email = $request->email;
        $user->password = $request->pass;
                $user->latitude = $request->latitude;
        $user->longitude = $request->longitude;

        $user->type=2;
        $user->is_active=0;
        $user->save();
        
     return response()->json(  [
        'response_code' => '200',
        'message' => 'Successfully registered'
            ], 200);
    }
    
    
        public function add_boys(Request $request){
        
                $exist = DeliveryBoy::where('email',$request->email)->first();
        if($exist){
             return response()->json(  [
                'response_code' => '201',
                'message' => 'Delivery Boy already exists'
                    ], 201);
            
        }
        $user = new DeliveryBoy();
        $user->name = $request->name;
        $user->address = $request->address;
        $user->phone = $request->phone;
        $user->email = $request->email;
        $user->password = $request->pass;
                $user->shop_id = $request->shop_id;

        $user->is_active=0;
        $user->save();
        
     return response()->json(  [
        'response_code' => '200',
        'message' => 'Successfully registered'
            ], 200);
    }


}
