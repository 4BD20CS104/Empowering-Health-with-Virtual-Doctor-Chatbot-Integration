<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Products;
use Illuminate\Http\RedirectResponse;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Validator;
use App\Models\Doctors;
use MongoDB\Driver\Manager;
use App\Models\ChatBot;

class AdminController extends Controller
{
    public function dashboard(Request $request)
    {
     $pcount=  Doctors::count();
       
        return view('dashboard',[
            "pcount"=> $pcount,
            ]);
    }


    public function message(Request $request)
    {
        $search = $request->has('search') ? $request['search'] : '';
        $query_param = ['search' => $search];

       
              $chat = ChatBot::when($request->has('search'), function ($query) use ($request) {
                $keys = explode(' ', $request['search']);
                return $query->where(function ($query) use ($keys) {
                    foreach ($keys as $key) {
                        $query->orWhere('msg', 'LIKE', '%' . $key . '%');
                    }
                });
            })
            ->latest()->paginate(10)->appends($query_param);
        return view('chat', compact('chat','search'));
    }
    
    
    
      public function messageStore(Request $request){
        $category = new ChatBot();
        $category->msg = $request->msg;
        $category->reply = $request->description;
        $category->save();
         Toastr::success('MSG added Successfully');

        return back();
    }
    
    public function messageUpdate($id,Request $request,)
   {
       $category = ChatBot::find($id);
      $category->msg = $request->msg;
       $category->save();
      Toastr::success('Chat updated Successfully');

        return back();    
   }
   
    public function messageDestroy($id,Request $request)
    {
         $delete = ChatBot::find($id);
         $delete->delete();
         Toastr::success('Chat Successfully');
         return back();
    }
    
            public function getSubs($id,Request $request)
    {
                $categories = Category::where('parent_id',$id)->orderBY('name', 'asc')->get();
                  $sub_category_id = $request->sub_category_id??null;
        return response()->json([
                    'data'=>$categories
                    ], 200);
    }

        public function subCategory(Request $request)
    {
        $search = $request->has('search') ? $request['search'] : '';
        $query_param = ['search' => $search];

              $mcategories =  Category::where('parent_id', "0")->get();

              $categories =  Category::where('parent_id','!=', "0")->when($request->has('search'), function ($query) use ($request) {
                $keys = explode(' ', $request['search']);
                return $query->where(function ($query) use ($keys) {
                    foreach ($keys as $key) {
                        $query->orWhere('name', 'LIKE', '%' . $key . '%');
                    }
                });
            })
            ->latest()->paginate(10)->appends($query_param);
            
        return view('subcategory', compact('categories','mcategories','search'));
    }
    
       public function users(Request $request)
    {
        $search = $request->has('search') ? $request['search'] : '';
        $query_param = ['search' => $search];

       
              $users = User::where('type',0)->when($request->has('search'), function ($query) use ($request) {
                $keys = explode(' ', $request['search']);
                return $query->where(function ($query) use ($keys) {
                    foreach ($keys as $key) {
                        $query->orWhere('name', 'LIKE', '%' . $key . '%');
                    }
                });
            })
            ->latest()->paginate(10)->appends($query_param);
        return view('user', compact('users','search'));
    }
    
    
      public function usersDestroy($id,Request $request)
    {
         $delete = User::find($id);
         $delete->delete();
          Toastr::success('Deleted Successfully');

         return back();
    }
    
      public function shops(Request $request)
    {
        $search = $request->has('search') ? $request['search'] : '';
        $query_param = ['search' => $search];

       
              $users = User::where('is_active',1)->where('type',2)->when($request->has('search'), function ($query) use ($request) {
                $keys = explode(' ', $request['search']);
                return $query->where(function ($query) use ($keys) {
                    foreach ($keys as $key) {
                        $query->orWhere('name', 'LIKE', '%' . $key . '%');
                    }
                });
            })
            ->latest()->paginate(10)->appends($query_param);
        return view('shops', compact('users','search'));
    }
    
        public function requsts_shops(Request $request)
    {
        $search = $request->has('search') ? $request['search'] : '';
        $query_param = ['search' => $search];

       
              $users = User::where('type',2)->where('is_active',0)->when($request->has('search'), function ($query) use ($request) {
                $keys = explode(' ', $request['search']);
                return $query->where(function ($query) use ($keys) {
                    foreach ($keys as $key) {
                        $query->orWhere('name', 'LIKE', '%' . $key . '%');
                    }
                });
            })
            ->latest()->paginate(10)->appends($query_param);
        return view('reqshops', compact('users','search'));
    }
    
        public function approveShop($id,Request $request,)
   {
       $shop = User::find($id);
       $shop->is_active = 1;
       $shop->save();
      Toastr::success('Shop approved Successfully');
        return redirect('admin/requsts_shops');    
   }
    
}