<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Products;
use Illuminate\Http\RedirectResponse;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use MongoDB\Driver\Manager;
use App\Models\ChatBot;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Http;
use App\Models\Temp;
use Illuminate\Support\Facades\Hash;
use App\Models\Doctors;
use App\Models\Bookings;

class ApiController extends Controller
{
    

 public function customer_login(Request $request){
        
        $user = User::where('email', $request->email)->first();
        if (isset($user) &&  Hash::check($request->pass, $user->password)) {
                return response()->json(  [
                'response_code' => '200',
                'msg' => 'Login Successfully'
                    ], 200);
        }
      return response()->json(  [
        'response_code' => '201',
        'msg' => 'Invalid Credentials'
            ], 200);
    }
    
         public function book(Request $request){
        
        $user = new Bookings();
        $user->name = $request->name;
        $user->address = $request->address;
        $user->gender = $request->gender;
        $user->phone=$request->phone;
        $user->doctor=$request->doctor;
        $user->save();
        
     return response()->json(  [
        'response_code' => '200',
        'msg' => 'Successfull'
            ], 200);
    }
    
        public function customer_register(Request $request){
        
                $exist = User::where('email',$request->email)->first();
if($exist){
     return response()->json(  [
        'response_code' => '201',
        'msg' => 'Account already exists'
            ], 201);
    
}
        $user = new User();
        $user->name = $request->name;
        $user->password = $request->pass;
        $user->email = $request->email;
        $user->type=0;
        $user->is_active=1;
        $user->save();
        
     return response()->json(  [
        'response_code' => '200',
        'msg' => 'Successfully registered'
            ], 200);
    }
    
    
      public function response(Request $request)
    {
       
         $searchTerm = $request->input('msg');


                $messages = ChatBot::when($searchTerm, function ($query) use ($searchTerm) {
                               return $query->where('msg', 'LIKE', "%$searchTerm%");
                           })->first();
                 $doctors = Doctors::when($searchTerm, function ($query) use ($searchTerm) {
                               return $query->where('diseases', 'LIKE', "%$searchTerm%");
                           })->first();
                           
            if (!$messages) {
              return response()->json(['message' => 'Please provide more info for better results'], 200);
            }

    return response()->json(['message' => $messages['reply'],'doctor' =>$doctors], 200);

    }
    
    
      public function saveData(Request $request)
    {
        $temp = new Temp();
        $temp->user_id =1;
        $temp->temp =$request->temp;
        $temp->heart_rate =$request->heart_rate;
        $temp->spo =$request->spo;
$temp->save();
           return response()->json(['status' => 'saved'], 200);

    }
 
 
     public function getData(Request $request)
    {
$latestMessage = Temp::latest()->first();
           return response()->json(['data' => $latestMessage], 200);

    }

 
}