<?php

namespace App\Http\Controllers;

use App\Models\Products;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Validator;
use App\Models\Doctors;
use MongoDB\Driver\Manager;
use Illuminate\Support\Facades\Storage;

class ProductsController extends Controller
{

    //
    public function doctors(Request $request)
    {
         $search = $request->has('search') ? $request['search'] : '';
        $query_param = ['search' => $search];

       
              $products = Doctors::when($request->has('search'), function ($query) use ($request) {
                $keys = explode(' ', $request['search']);
                return $query->where(function ($query) use ($keys) {
                    foreach ($keys as $key) {
                        $query->orWhere('doctor_name', 'LIKE', '%' . $key . '%');
                    }
                });
            })
                        ->latest()->get();


        return view('doctors', compact('products','search'));
    }
    
    public function upload(){
        
                return view('addDoctor');

    }
    
    public function store(Request $request){
        $doctor=  new Doctors();
        $doctor->doctor_name = $request->name;
        $doctor->designation = $request->designation;
        $doctor->address = $request->address;
        $doctor->phone = $request->phone;
                $doctor->diseases = $request->diseases;

        $doctor->save();
        
        Toastr::success('Doctor added Successfully');
         return back();
    }
    
      
      public function destroy($id,Request $request)
    {
         $delete = Doctors::find($id);
     $delete->delete();
     Toastr::success('Deleted Successfully');

         return back();
    }
}
