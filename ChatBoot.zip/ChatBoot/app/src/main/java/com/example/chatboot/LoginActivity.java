package com.example.chatboot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.chatboot.api.APIService;
import com.example.chatboot.api.Client;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {


    APIService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        findViewById(R.id.create).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, SignupActivity.class));
            }
        });

        EditText email = findViewById(R.id.emailET);
        EditText pass = findViewById(R.id.passwordET);
        apiService = Client.getClient("https://beauty.blactrontech.com/api/").create(APIService.class);

        findViewById(R.id.submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (email.getText().toString().isEmpty() && pass.getText().toString().isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Fill the detail", Toast.LENGTH_SHORT).show();
                } else {
                    apiService.login(email.getText().toString(), pass.getText().toString()).enqueue(new Callback<JsonObject>() {
                        @Override
                        public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                            if (response.isSuccessful()) {
                                JsonObject responseData = response.body();
                                if(responseData.get("response_code").getAsString().equals("200")) {
                                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                                }
                                Toast.makeText(LoginActivity.this, responseData.get("msg").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<JsonObject> call, Throwable t) {

                        }
                    });
                }
            }
        });

    }
}