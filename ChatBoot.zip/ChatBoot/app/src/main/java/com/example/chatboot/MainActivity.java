package com.example.chatboot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.chatboot.api.APIService;
import com.example.chatboot.api.Client;
import com.example.chatboot.model.Chat;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    APIService apiService;

TextView heart,temp,spo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        apiService = Client.getClient("https://beauty.blactrontech.com/api/").create(APIService.class);
        heart =  findViewById(R.id.tvHeartRateValue);
        spo =  findViewById(R.id.tvSpO2Value);
        temp =  findViewById(R.id.tvTemperatureValue);

        findViewById(R.id.chat_bot).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,ChatActivity.class));
            }
        });
        apiService.mainData().enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()){
                    JsonObject responseData = response.body();
                    heart.setText(responseData.getAsJsonObject("data").get("heart_rate").getAsString()+" BPM");
                    temp.setText(responseData.getAsJsonObject("data").get("temp").getAsString()+"°C");
                    spo.setText(responseData.getAsJsonObject("data").get("spo").getAsString()+"%");

                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });
    }
}