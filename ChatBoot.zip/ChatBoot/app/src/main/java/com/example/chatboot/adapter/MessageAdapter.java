package com.example.chatboot.adapter;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.chatboot.R;
import com.example.chatboot.Typewriter;
import com.example.chatboot.model.Chat;

import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {

    public static  final int MSG_TYPE_LEFT = 0;
    public static  final int MSG_TYPE_RIGHT = 1;

    private Context mContext;
    private List<Chat> mChat;
    private Set<Integer> animatedPositions = new HashSet<>(); // To keep track of animated positions

    public MessageAdapter(Context mContext, List<Chat> mChat){
        this.mChat = mChat;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == MSG_TYPE_RIGHT) {
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_right, parent, false);
            return new ViewHolder(view);
        } else {
            View view = LayoutInflater.from(mContext).inflate(R.layout.chat_item_left, parent, false);
            return new ViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Chat chat = mChat.get(position);
        holder.bind(chat,position);


    }

    @Override
    public int getItemCount() {
        return mChat.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder{

        public Typewriter show_message;

        public ViewHolder(View itemView) {
            super(itemView);

            show_message = itemView.findViewById(R.id.show_message);
        }

        public void bind(Chat chat,int position) {
            if(getItemViewType()== MSG_TYPE_RIGHT){
                show_message.setText(chat.getMessage());
                animatedPositions.add(position);

            }
            if (!animatedPositions.contains(position)) { // Check if animation already applied

                show_message.setCharacterDelay(60);
                show_message.animateText(chat.getMessage());
                animatedPositions.add(position);
            }else{
                show_message.setText(chat.getMessage());

            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        switch (mChat.get(position).getSender()) {
            case "user":
                return MSG_TYPE_RIGHT;
            case "bot":
                return MSG_TYPE_LEFT;
            default:
                return -1;
        }

    }
}