package com.example.chatboot.api;

import com.google.gson.JsonObject;

import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface APIService {

    @GET("response")
    Call<JsonObject> response(@Query("msg") String msg);

    @GET("getData")
    Call<JsonObject> mainData();

    @GET("login")
    Call<JsonObject> login(@Query("email") String email,@Query("pass") String pass);


    @GET("register")
    Call<JsonObject> register(@Query("email") String email,@Query("pass") String pass,@Query("name") String name);

    @GET("book")
    Call<JsonObject> book(@Query("name") String name,@Query("address") String address,@Query("gender") String gender,@Query("phone") String phone,@Query("doctor") String doctor);


}
