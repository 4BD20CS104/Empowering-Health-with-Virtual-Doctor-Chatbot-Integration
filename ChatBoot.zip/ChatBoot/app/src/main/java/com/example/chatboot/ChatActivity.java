package com.example.chatboot;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.chatboot.adapter.MessageAdapter;
import com.example.chatboot.api.APIService;
import com.example.chatboot.api.Client;
import com.example.chatboot.model.Chat;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatActivity extends AppCompatActivity {

    ImageButton btn_send;
    EditText text_send;

    MessageAdapter messageAdapter;
    List<Chat> mchat;

    RecyclerView recyclerView;

    Intent intent;

    APIService apiService;

    boolean notify = false;
    private final String USER_KEY = "user";
    private final String BOT_KEY = "bot";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        btn_send = findViewById(R.id.btn_send);
        text_send = findViewById(R.id.text_send);
        intent = getIntent();
        apiService = Client.getClient("https://beauty.blactrontech.com/api/").create(APIService.class);
        mchat = new ArrayList<>();

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                notify = true;
                String msg = text_send.getText().toString();
                if (!msg.equals("")) {
                    if (booking) {
                        mchat.add(new Chat(msg, USER_KEY));
                        if (name.isEmpty()) {
                            name = msg;

                            mchat.add(new Chat("Enter your gender", BOT_KEY));
                            messageAdapter.notifyDataSetChanged();
                            text_send.setText("");
                            recyclerView.scrollToPosition(mchat.size() - 1);

                            return;
                        }
                        if (gender.isEmpty()) {
                            gender = msg;
                            mchat.add(new Chat("Enter your address", BOT_KEY));
                            messageAdapter.notifyDataSetChanged();
                            text_send.setText("");
                            recyclerView.scrollToPosition(mchat.size() - 1);

                            return;
                        }

                        if (address.isEmpty()) {
                            address = msg;
                            mchat.add(new Chat("Enter your phone", BOT_KEY));
                            messageAdapter.notifyDataSetChanged();
                            text_send.setText("");
                            recyclerView.scrollToPosition(mchat.size() - 1);

                            return;
                        }

                        if (phone.isEmpty()) {
                            phone = msg;
                            mchat.add(new Chat("Please confirm your booking\nType CONFIRM", BOT_KEY));
                            messageAdapter.notifyDataSetChanged();
                            text_send.setText("");
                            recyclerView.scrollToPosition(mchat.size() - 1);

                            return;
                        }


                        if (msg.toLowerCase().contains("confirm")) {
                            Toast.makeText(ChatActivity.this, "Booking in Progress", Toast.LENGTH_SHORT).show();
                            apiService.book(name, address, gender, phone, doctorData.get("id").toString()).enqueue(new Callback<JsonObject>() {
                                @Override
                                public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                                    if (response.isSuccessful()) {
                                        mchat.add(new Chat("Booked Successfully", BOT_KEY));
                                        messageAdapter.notifyDataSetChanged();
                                        booking = false;
                                        recyclerView.scrollToPosition(mchat.size() - 1);

                                    }
                                }

                                @Override
                                public void onFailure(Call<JsonObject> call, Throwable t) {
                                    Log.d("Sdfdsc", t.getMessage());
                                    booking = false;
                                    mchat.add(new Chat("Booking failed", BOT_KEY));
                                    messageAdapter.notifyDataSetChanged();
                                    recyclerView.scrollToPosition(mchat.size() - 1);


                                }
                            });
                            text_send.setText("");


                        } else {
                            booking = false;
                            mchat.add(new Chat("Booking not completed\nTry later", BOT_KEY));
                            messageAdapter.notifyDataSetChanged();
                            text_send.setText("");
                            recyclerView.scrollToPosition(mchat.size() - 1);

                        }

                    } else {
                        sendMessage(msg);
                    }
                } else {
                    Toast.makeText(ChatActivity.this, "You can't send empty message", Toast.LENGTH_SHORT).show();
                }
                text_send.setText("");
            }
        });

        messageAdapter = new MessageAdapter(ChatActivity.this, mchat);
        recyclerView.setAdapter(messageAdapter);
        mchat.add(new Chat("Hello!\nHow Can i Help you", BOT_KEY));
        messageAdapter.notifyDataSetChanged();
    }

    JsonObject doctorData;
    boolean booking = false;
    String name = "";
    String address = "";
    String gender = "";
    String phone = "";

    private void sendMessage(String msg) {
        mchat.add(new Chat(msg, USER_KEY));
        Log.d("sdfzcdfx", msg.toLowerCase());
        Log.d("sdfzcdfx", msg.toLowerCase().contains("find a doctor") + "");

        if (msg.toLowerCase().contains("find a doctor")) {
            if (doctorData != null) {
                mchat.add(new Chat("Doctor :- " + doctorData.get("doctor_name").toString()
                        + "\nAddress : -" + doctorData.get("address").toString()
                        + "\nDesignation : -" + doctorData.get("designation").toString()
                        + "\nPhone : -" + doctorData.get("phone").toString(), BOT_KEY));
                messageAdapter.notifyDataSetChanged();
                recyclerView.scrollToPosition(mchat.size() - 1);

            }else{
                mchat.add(new Chat("Reenter your problem", BOT_KEY));
                messageAdapter.notifyDataSetChanged();
                recyclerView.scrollToPosition(mchat.size() - 1);
                Toast.makeText(this, "Doctor not found", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        if (msg.toLowerCase().contains("book an appointment")) {
            if (doctorData != null) {
                mchat.add(new Chat("Booking Form", BOT_KEY));
                messageAdapter.notifyDataSetChanged();
                mchat.add(new Chat("Enter your name", BOT_KEY));
                messageAdapter.notifyDataSetChanged();
                booking = true;
                recyclerView.scrollToPosition(mchat.size() - 1);

                return;
            } else {
                mchat.add(new Chat("Doctor not found", BOT_KEY));
                messageAdapter.notifyDataSetChanged();
                mchat.add(new Chat("Please tell me again your problem", BOT_KEY));
                messageAdapter.notifyDataSetChanged();
                recyclerView.scrollToPosition(mchat.size() - 1);

            }
        }

        apiService.response(msg).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    JsonObject responseData = response.body();
                    if (responseData != null && !responseData.isJsonNull()) {
                        JsonElement dataElement = responseData.get("doctor");
                        if (!dataElement.isJsonNull()) {
                            if (responseData.getAsJsonObject("doctor") != null) {
                                doctorData = responseData.getAsJsonObject("doctor");
                                Toast.makeText(ChatActivity.this, "Doctor found", Toast.LENGTH_SHORT).show();
                                Log.d("sdfzcdfx", responseData.getAsJsonObject("doctor").toString());
                            }
                        }
                    }
                    mchat.add(new Chat(responseData.get("message").getAsString(), BOT_KEY));
                    messageAdapter.notifyDataSetChanged();
                    recyclerView.scrollToPosition(mchat.size() - 1);

                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}