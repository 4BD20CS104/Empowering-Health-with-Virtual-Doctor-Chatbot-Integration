package com.example.chatboot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.chatboot.api.APIService;
import com.example.chatboot.api.Client;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity {

    APIService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        findViewById(R.id.login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignupActivity.this, LoginActivity.class));
            }
        });

        EditText email = findViewById(R.id.emailET);
        EditText pass = findViewById(R.id.passwordET);
        EditText username = findViewById(R.id.username);
        apiService = Client.getClient("https://beauty.blactrontech.com/api/").create(APIService.class);
        findViewById(R.id.submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (username.getText().toString().isEmpty() && email.getText().toString().isEmpty() && pass.getText().toString().isEmpty()) {
                    Toast.makeText(SignupActivity.this, "Fill the detail", Toast.LENGTH_SHORT).show();
                } else {
                    apiService.register(email.getText().toString(), pass.getText().toString(),username.getText().toString()).enqueue(new Callback<JsonObject>() {
                        @Override
                        public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                            if (response.isSuccessful()) {
                                JsonObject responseData = response.body();
                                if(responseData.get("response_code").getAsString().equals("200")) {
                                    startActivity(new Intent(SignupActivity.this, LoginActivity.class));
                                }
                                Toast.makeText(SignupActivity.this, responseData.get("msg").getAsString(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<JsonObject> call, Throwable t) {
                            Log.d("Sdfdsc",t.getMessage());

                        }
                    });
                }
            }
        });


    }
}